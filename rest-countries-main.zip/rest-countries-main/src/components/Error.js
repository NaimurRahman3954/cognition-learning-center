export default function Error() {
    return(
        <div>
        <h2>Error</h2>    
        </div>
    )
}